package com.algaworks.algatransito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgatransitoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgatransitoApiApplication.class, args);
	}

}

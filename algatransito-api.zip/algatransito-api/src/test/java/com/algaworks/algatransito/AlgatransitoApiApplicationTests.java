package com.algaworks.algatransito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgatransitoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
